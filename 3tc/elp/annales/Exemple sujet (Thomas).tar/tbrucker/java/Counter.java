import javax.swing.*;  
import java.awt.*;      
import java.awt.event.*; 
import java.util.*; 

/** Small class that provides a way to compute 
the proportion of clics on a button */
class TbruckerCounter {
    private int me, all;
    public void itsMe() {
	me++; 
	all++; 
    }
    public void notMe() {
	all++; 
    }
    public double getRatio() {
	return me / (double) all; 
    }
}

/** window listener that displays the computed ratio on closing */
class OnCloseListener extends WindowAdapter implements WindowListener {
    public TbruckerCounter tbrucker; 
    public OnCloseListener(TbruckerCounter tbrucker) {
	this.tbrucker = tbrucker;
    }
    @Override 
    public void windowClosing(WindowEvent e) {
	System.out.println(tbrucker.getRatio()); 
    }
}

/** Main class that counts the proportion of clics on the "tbr" button */
public class Counter implements Runnable {

    @Override 
    public void run() {

        JFrame f = new JFrame("Counter");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	TbruckerCounter tbrucker = new TbruckerCounter(); 
        f.addWindowListener(new OnCloseListener(tbrucker));

	JPanel panel = new JPanel(new GridLayout(0,2)); 
	Map<JButton,String> names = new HashMap<JButton,String>(); 
	names.put(new JButton("ldu"), "ldubois"); 
	names.put(new JButton("tbr"), "tbrucker"); 
	names.put(new JButton("jpe"), "jpetit"); 
	names.put(new JButton("bre"), "brenard");
	for (JButton b: names.keySet()) {
	    panel.add(b);  
	}

        f.getContentPane().add(panel);
        f.pack();
        f.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater( new Counter() );  
    }
}
