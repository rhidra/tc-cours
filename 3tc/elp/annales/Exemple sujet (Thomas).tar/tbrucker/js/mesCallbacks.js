function sfrenot1() {
  console.log("tbrucker1 Je suis une fonction à callback");
  console.log("tbrucker1 Je ne suis pas une fonction à callback");
  return "tbrucker";
}

function tbrucker2(a, b) {
  console.log("tbrucker2 je suis une fonction à callback");
  console.log("tbrucker2 je ne suis pas une fonction à callback");
  return b();
}

function tbrucker3(a, b) {
  console.log("tbrucker3 je suis une fonction à callback");
  console.log("tbrucker3 je ne suis pas une fonction à callback")
  return b;
}

console.log(tbrucker1(1, sfrenot1));
console.log(tbrucker2(1, sfrenot1));
console.log(tbrucker3(1, sfrenot1));
