//_ = require('lodash')
var tab = [{stephane:1}, {tbrucker:2}, {tristan:1}]

function tbrucker1() {
  for(i=0; i < tab.length; i++) {
    console.log("tabImperatif", tab[i])
  }
}

function tbrucker2() {
  // Utilisez la fonction forEach sur tab
  console.log("tbrucker2, il faut utiliser forEach")
}

function tbrucker3() {
  // Utilisez la bibliothèque lodash
  console.log("tbrucker3, il faut utiliser lodash")
}

tbrucker1();
tbrucker2();
tbrucker3();
