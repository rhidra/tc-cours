package main

import (
	"fmt"
	"time"
)

func fibonacci(c chan int) {
	// fonction à completer
	// cette fonction doit renvoyer sur le canal c
	// le numero suivant de la suite
	// chaque 300 milliseconds
	nextFib =1
	currentFib = 0
	numberTick := time.Tick(300 * time.Millisecond)
	for{
		<-numberTick
		tmp = nextFib
		nextFib = nextFib + currentFib
		currentFib = tmp
		c <- nextFib // Send the next fibonacci number to c channel
	}
}

func main() {
	endSignal := time.After(10000 * time.Millisecond)
	n := make(chan int)
	go fibonacci(n)
	for {
		select {
		case numero := <-n:
			fmt.Print(numero)
		case <-endSignal:
			fmt.Println("BINGO!")
			return
		default:
			fmt.Print(".")
			time.Sleep(50 * time.Millisecond)
		}
	}
}
