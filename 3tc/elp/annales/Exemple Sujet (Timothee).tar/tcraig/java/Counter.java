import javax.swing.*;  
import java.awt.*;      
import java.awt.event.*;
import java.io.File;
import java.util.*;

/** Small class that provides a way to compute 
the proportion of clics on a button */
class TcraigCounter {
    private int me, all;
    public void itsMe() {
	me++; 
	all++; 
    }
    public void notMe() {
	all++; 
    }
    public double getRatio() {
	return me / (double) all; 
    }
}

/** window listener that displays the computed ratio on closing */
class OnCloseListener extends WindowAdapter implements WindowListener {
    public TcraigCounter tcraig; 
    public OnCloseListener(TcraigCounter tcraig) {
	this.tcraig = tcraig;
    }
    @Override 
    public void windowClosing(WindowEvent e) {
	System.out.println(tcraig.getRatio()); 
    }
}

/** Main class that counts the proportion of clics on the "tcr" button */
public class Counter implements Runnable {

    public CounterListener counterListener;

    @Override 
    public void run() {

        try{

            File file = new File("historique.log");
            if(file.delete()){
                System.out.println("Ancien historique supprimé!");
            }else{
                System.out.println("Pas d'ancien historique.");
            }
        }catch(Exception e){
            e.printStackTrace();
        }

        JFrame f = new JFrame("Counter");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        f.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                onWClose();
                System.exit(0);
            }
        });

	TcraigCounter tcraig = new TcraigCounter();
        f.addWindowListener(new OnCloseListener(tcraig));

        counterListener = new CounterListener();

	JPanel panel = new JPanel(new GridLayout(0,2)); 
	Map<JButton,String> names = new HashMap<JButton,String>(); 
	names.put(new JButton("ldu"), "ldubois"); 
	names.put(new JButton("tcr"), "tcraig"); 
	names.put(new JButton("jpe"), "jpetit"); 
	names.put(new JButton("bre"), "brenard");
	for (JButton b: names.keySet()) {
        b.addActionListener(counterListener);
	    panel.add(b);  
	}

        f.getContentPane().add(panel);
        f.pack();
        f.setVisible(true);
    }

    public void onWClose() {
        int tcrClick = this.counterListener.getTcrClickCount();
        int totalClick = this.counterListener.getTotalClickCount();
        System.out.println(tcrClick + " " + totalClick);
        double rapport = ((double)tcrClick / (double)totalClick);
        System.out.println("Rapport : " + rapport);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater( new Counter() );  
    }
}
