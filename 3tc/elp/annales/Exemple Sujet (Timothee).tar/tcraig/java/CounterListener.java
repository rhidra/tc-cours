import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;

/**
 * Created by timothee on 23/05/17.
 */
public class CounterListener implements ActionListener {

    private int tcrClickCount;
    private int totalClickCount;

    public CounterListener() {
        this.tcrClickCount = 0;
        this.totalClickCount = 0;
    }

    public int getTcrClickCount() {
        return tcrClickCount;
    }

    public int getTotalClickCount() {
        return totalClickCount;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        String nameToWrite = "";

        this.totalClickCount++;
        if(e.getActionCommand().equalsIgnoreCase("tcr")) {
            this.tcrClickCount++;
        }

        switch (e.getActionCommand()) {
            case "tcr":
                nameToWrite = "tcraig";
                break;
            case "ldu":
                nameToWrite = "ldubois";
                break;
            case "jpe":
                nameToWrite = "jpetit";
                break;
            case "bre":
                nameToWrite = "brenard";
                break;
            default: break;
        }

        System.out.println(nameToWrite);
        // TODO: write "naemToWrite" to file here
        try {
            FileWriter fw = new FileWriter("historique.log", true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw);
            out.println(nameToWrite);
            out.close();
        } catch (Exception except) {
            except.printStackTrace();
        }

    }
}
