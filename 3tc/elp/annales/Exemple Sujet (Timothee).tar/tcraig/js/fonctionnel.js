_ = require('lodash')
var tab = [{stephane:1}, {tcraig:2}, {tristan:1}]

function tcraig1() {
  for(i=0; i < tab.length; i++) {
    console.log("tabImperatif", tab[i])
  }
}

function tcraig2() {
  // Utilisez la fonction forEach sur tab
  console.log("tcraig2, il faut utiliser forEach")
  tab.forEach((element) => {
    console.log(element);
  });
}

function tcraig3() {
  // Utilisez la bibliothèque lodash
  console.log("tcraig3, il faut utiliser lodash")
  _.forEach(tab, (element) => {console.log(element);})
}

tcraig1();
tcraig2();
tcraig3();
