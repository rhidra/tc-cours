function sfrenot1() {
  //console.log("tcraig1 Je suis une fonction à callback");
  console.log("tcraig1 Je ne suis pas une fonction à callback");
  return "tcraig";
}

function tcraig2(a, b) {
  console.log("tcraig2 je suis une fonction à callback");
  //console.log("tcraig2 je ne suis pas une fonction à callback");
  return b();
}

function tcraig3(a, b) {
  console.log("tcraig3 je suis une fonction à callback");
  //console.log("tcraig3 je ne suis pas une fonction à callback")
  return b;
}

console.log(sfrenot1(1, sfrenot1)); // Corrigé de tcraig1 -> sfrenot1
console.log(tcraig2(1, sfrenot1));
console.log(tcraig3(1, sfrenot1));
