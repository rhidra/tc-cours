def find_max_len(*args):
    lengths = []
    if(len(args) != 0):
        for e in args:
            lengths.append(len(e))
        print(max(lengths))
    else:
        print(0)

def Reversed(seq):
    for idx in range(len(seq)-1, -1, -1):
        yield seq[idx]


a = ["tcraig", "giarct"]
b = [None, 666, (True, False)]
c = ["jäger", "chartreuse", "armagnac", "carlsberg"]

a_reversed = ["giarct", "tcraig"]
b_reversed = [(True, False), 666, None]
c_reversed = ["carlsberg","armagnac","chartreuse","jäger"]

find_max_len(a,b,c)
find_max_len()

g = Reversed(a)
#Affichage :
for e in g:
    print(e)
